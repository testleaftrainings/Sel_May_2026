package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001_CreateLead extends BaseClass{
   @BeforeTest
   public void setValues(){
     filename="CreateLead";
     testcaseName="CreateLead";
     testcaseDescription="CreateLead with multiple data";
     testAuthor="Vineeth"; 
     testCategory="Regression";
   }

    @Test(dataProvider="fetchData")
    public void createLead(String username, String password,String cName, String fName, String lName) throws IOException{
    LoginPage lp=new LoginPage();        //ABCD1234
    lp.enterUsername(username)
    .enterPassword(password)
    .clickLoginButton()
    .clickCrmsfa()
    .clickLeadsLink()
    .clickCreateLeadLink()
    .enterCompanyName(cName)
    .enterFirstName(fName)
    .enterLastName(lName)
    .clickCreateLeadButton()
    .verifyLead();
    
    }

}
