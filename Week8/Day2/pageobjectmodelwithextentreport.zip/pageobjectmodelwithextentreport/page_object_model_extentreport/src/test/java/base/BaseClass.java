package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests {

    //public EdgeDriver driver;

    private static final ThreadLocal<EdgeDriver> driver=new ThreadLocal<EdgeDriver>();
    public String filename;
    public static ExtentReports extent;
    public String testcaseName, testcaseDescription, testAuthor, testCategory;
    public static ExtentTest test;


   public void setter(){
    driver.set(new EdgeDriver());
   }

   public EdgeDriver getter(){
    return driver.get();
   }



    @BeforeMethod
    public void preConditions(){
    //driver=new EdgeDriver();                       //ABCD1234
    setter();
    getter().get("https://leaftaps.com/opentaps");
    getter().manage().window().maximize();
    getter().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    }

    @AfterMethod
      public void postConditions(){
      getter().close();
    }
    @DataProvider(name="fetchData")
    public String[][] sendData() throws IOException{
      return ReadExcel.readData(filename);    //Login
    }

    @BeforeSuite
    public void startReport(){
              //Step1:Setup the path
    ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/leaftapsreport.html");

    //Step2: Create the report
    extent=new ExtentReports();

    //step3: attach the data
    extent.attachReporter(reporter);
    }


    @BeforeClass
    public void testCaseDetails(){
      test=extent.createTest(testcaseName, testcaseDescription);
      test.assignAuthor(testAuthor);
      test.assignCategory(testCategory);
    }

   public void reportStep(String status, String message) throws IOException{
    if(status.equalsIgnoreCase("Pass")){
      test.pass(message,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/image"+takeSnap()+".png").build());
    }
   }

   public int takeSnap() throws IOException{

    //int number=(int)(0.55666);

    int randNumber= (int)(Math.random()*9999999+9999999);
       //System.out.println(randNumber);
    File source=getter().getScreenshotAs(OutputType.FILE);

    File destination=new File("./snaps/image"+randNumber+".png");

    FileUtils.copyFile(source, destination);

    return randNumber;
   }



    @AfterSuite
    public void stopReport(){
      extent.flush();
    }

}
