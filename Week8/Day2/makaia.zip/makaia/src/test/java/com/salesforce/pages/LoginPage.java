package com.salesforce.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{

    public LoginPage enterUserName(String uName) {
		
	    clearAndType(locateElement("username"), uName);
		reportStep("Entered  UserName is :"+uName, "pass");
		return this;

	}
	
	public LoginPage enterPassword(String pass) {
	
		clearAndType(locateElement(Locators.ID, "password"), pass);
		reportStep("Entered PassWord is :"+pass, "pass");
		return this;
	}
	
	public void clickOnLogin() {
		click(locateElement(Locators.CLASS_NAME, "decorativeSubmit"));
		reportStep("Login is Clicked Successfully", "pass");
		
	}
}
