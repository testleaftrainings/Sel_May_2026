package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition extends BaseClass {

   

    @When("Enter the username as {string}")
    public void enterUsername(String username){
        driver.findElement(By.id("username")).sendKeys(username);
    }

  
   @And("Enter the password as {string}")
    public void enterPassword(String password){
        driver.findElement(By.id("password")).sendKeys(password);
    }

     @And("Enter the password as crm")
    public void enterPassword1(){
        driver.findElement(By.id("password")).sendKeys("crm");
    }

    @And("Click the Login button")
    public void clickLogin(){
        driver.findElement(By.className("decorativeSubmit")).click();
    }

    @Then("The user should be loggedin")
    public void verifyLogin(){
        System.out.println("Login successful");
    }

    @But("It throws the error message")
    public void verifyErrorMessage(){
       System.out.println("Error Message thrown"); 
    }

}
