package steps;

import io.cucumber.java.en.Then;

import org.openqa.selenium.By;

import io.cucumber.java.en.And;

public class CreateLeadStepDefinition extends BaseClass {

@And("Click on the CRMSFA link")
public void click_on_the_crmsfa_link() {
driver.findElement(By.linkText("CRM/SFA")).click();
}

@And("Click on the Leads link")
public void click_on_the_leads_link() {
driver.findElement(By.linkText("Leads")).click();
}

@And("Click on the Create Lead link")
public void click_on_the_create_lead_link() {
driver.findElement(By.linkText("Create Lead")).click();
}

@And("Enter the companyname as (.*)$")
public void enter_the_companyname_as_test_leaf(String companyName) {
driver.findElement(By.id("createLeadForm_companyName")).sendKeys(companyName);
}

@And("Enter the firstname as (.*)$")
public void enter_the_firstname_as_vineeth(String firstname) {
driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstname);
}

@And("Enter the lastname as (.*)$")
public void enter_the_lastname_as_rajendran(String lastname) {
driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastname);
}

@And("Click on the Create Lead button")
public void click_on_the_create_lead_button() {
driver.findElement(By.name("submitButton")).click();
}

@Then("The Lead should be created")
public void the_lead_should_be_created() {
System.out.println("Lead is created");
}

}
