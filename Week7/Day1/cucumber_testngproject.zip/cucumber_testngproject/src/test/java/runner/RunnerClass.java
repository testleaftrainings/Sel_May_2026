package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import steps.BaseClass;

@CucumberOptions(features="src/test/resources",glue="steps",tags="@Smoke or @Sanity")
public class RunnerClass extends BaseClass
 {

}

//and both
//or  anyone