Feature: CreateLead function of Leaftaps application

@Regression @Smoke
Scenario Outline: CreateLead with multiple data

When Enter the username as 'Demosalesmanager'
And Enter the password as 'crmsfa'
And Click the Login button
And Click on the CRMSFA link
And Click on the Leads link
And Click on the Create Lead link
And Enter the companyname as <companyname>
And Enter the firstname as <firstname>
And Enter the lastname as <lastname>
And Click on the Create Lead button
Then The Lead should be created

Examples:
|companyname|firstname|lastname|
|Testleaf|Vineeth|Rajendran|
|Qeagle|Hari|R|
