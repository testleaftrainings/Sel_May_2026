Feature: Login function of Leaftaps application

@Smoke @Sanity
Scenario: Login with valid credentials
When Enter the username as 'Demosalesmanager'
And Enter the password as 'crmsfa'
And Click the Login button
Then The user should be loggedin

@Sanity
Scenario: Login with invalid credentials
When Enter the username as 'Demo'
And Enter the password as 'crm'
And Click the Login button
But It throws the error message
