package steps;

import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class HooksImplementation extends BaseClass {

    @Before
    public void preConditions(){
    driver=new EdgeDriver();
    driver.get("https://leaftaps.com/opentaps/control/main");
    }

    @After
     public void postConditions(){
     driver.close();
    }


}
