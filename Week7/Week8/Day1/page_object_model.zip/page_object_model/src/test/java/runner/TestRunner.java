package runner;


import base.BaseClass;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features = "src/test/resources",glue="pages")
public class TestRunner extends BaseClass {

}


