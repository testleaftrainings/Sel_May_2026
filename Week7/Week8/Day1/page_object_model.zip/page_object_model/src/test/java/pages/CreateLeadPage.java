package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass{

 

    @And("Enter the Companyname as (.*)$")
    public CreateLeadPage enterCompanyName(String cName){
    getter().findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
    return this;
    }

    @And("Enter the Firstname as (.*)$")
     public CreateLeadPage enterFirstName(String fName){
        getter().findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
        return this;
    }

    @And("Enter the Lastname as (.*)$")
     public CreateLeadPage enterLastName(String lName){
        getter().findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
        return this;
    }

    @When("Click on the CreateLead button")
     public ViewLeadPage clickCreateLeadButton(){
        getter().findElement(By.name("submitButton")).click();
        return new ViewLeadPage();
    }

}
