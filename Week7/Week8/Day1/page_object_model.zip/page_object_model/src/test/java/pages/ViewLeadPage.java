package pages;

import org.openqa.selenium.edge.EdgeDriver;
import io.cucumber.java.en.Then;

import base.BaseClass;

public class ViewLeadPage extends BaseClass {

   

    @Then("Lead should be creates")
    public void verifyLead(){
        System.out.println("Lead is Created");
    }

}
