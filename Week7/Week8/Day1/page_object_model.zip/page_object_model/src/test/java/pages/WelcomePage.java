package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass {


    @Then("User should be loggedin")
    public void verifyLogin(){
    System.out.println("Loggedin Successful");
    }



    @When("Click on the Crmsfa link")
    public MyHomePage clickCrmsfa(){

        getter().findElement(By.partialLinkText("CRM")).click();
        //MyHomePage hp=new MyHomePage();
        //return hp;
        return new MyHomePage();   //ABCD1234
    }

}
