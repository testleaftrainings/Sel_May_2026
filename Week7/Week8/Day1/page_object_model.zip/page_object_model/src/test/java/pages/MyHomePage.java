package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;

public class MyHomePage extends BaseClass {

    

    @And("Click on the Leads link")
    public MyLeadsPage clickLeadsLink(){

       getter().findElement(By.linkText("Leads")).click(); 
       return new MyLeadsPage();
    }

}
