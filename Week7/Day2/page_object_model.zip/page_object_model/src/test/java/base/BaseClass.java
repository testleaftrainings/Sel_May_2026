package base;

import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseClass {

    public EdgeDriver driver;

    @BeforeMethod
    public void preConditions(){
driver=new EdgeDriver();
driver.get("https://leaftaps.com/opentaps/control/main");
driver.manage().window().maximize();

    }
@AfterMethod
      public void postConditions(){
driver.close();
    }

}
