package testcases;

public class Learnconstructor {

    int number;
    String name;

    public Learnconstructor(){
    System.out.println("This is from default Constrctor");
    }
//                                 21        Bharath
    public Learnconstructor(int number,String name){
        //            21            
        this.number=number;
        //           Bharath
        this.name=name;
    }

    public static void main(String argss[]){
    //Learnconstructor lc1=new Learnconstructor();
    //System.out.println(lc1.number);
    //System.out.println(lc1.name);

    Learnconstructor lc2=new Learnconstructor(21,"Bharath");
     System.out.println(lc2.number);
    System.out.println(lc2.name);
    }



}
