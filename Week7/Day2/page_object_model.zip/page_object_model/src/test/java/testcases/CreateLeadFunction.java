package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateLeadFunction extends BaseClass {
@Test
    public void createLead(){
LoginPage lp=new LoginPage(driver);
lp.enterUsername()
.enterPassword()
.clickLoginButton()
.clickCrmsfa()
.clickLeadsLink()
.clickCreateLeadLink()
.enterCompanyName()
.enterFirstName()
.enterLastName()
.clcikSubmitButton()
.verifyLead();

}

}
