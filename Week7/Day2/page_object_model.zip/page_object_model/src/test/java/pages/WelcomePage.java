package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;

public class WelcomePage extends BaseClass{


  public WelcomePage(EdgeDriver driver){
    //           abc
    this.driver=driver;
    }


     public MyHomePage clickCrmsfa(){
driver.findElement(By.linkText("CRM/SFA")).click();
//MyHomePage hp=new MyHomePage();
//return hp;
return new MyHomePage(driver);
    }

}
