package pages;

import org.openqa.selenium.edge.EdgeDriver;

import base.BaseClass;

public class ViewLeadsPage extends BaseClass {
    public ViewLeadsPage(EdgeDriver driver){
    this.driver=driver;
    }

    public void verifyLead(){
        System.out.println("Lead is Created");
    }

}
