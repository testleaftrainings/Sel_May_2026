package testcases;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

public class BaseClass {

    public EdgeDriver driver;
	public String filename;

@Parameters({"url","username","password"})
@BeforeMethod
public void preConditions(String URL , String uName, String pWord){
        driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.id("username")).sendKeys(uName);
		driver.findElement(By.id("password")).sendKeys(pWord);
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
}


@AfterMethod
public void postConditions(){
    driver.close();
}

@DataProvider(name="fetch")
public String[][] sendData() throws IOException{
    String[][] data = ReadExcel.readData(filename);  //EditLead
	return data;

}

}
