package testcases;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
                                      //EditLead
    public static String[][] readData(String filename) throws IOException {
        //step1: locate the workbook
        //XSSFWorkbook wb=new XSSFWorkbook("TestNG_New/testng_configuration_project/Data/CreateLead.xlsx");

       XSSFWorkbook wb=new XSSFWorkbook("Data/"+filename+".xlsx");

        //Step2: Locate the worksheet
        XSSFSheet ws = wb.getSheet("Sheet1");

        //Step3:Retreive the data
        //rowCount
        int rowCount = ws.getLastRowNum();
        System.out.println("rowCount is: "+rowCount);

        int physicalNumberOfRows = ws.getPhysicalNumberOfRows();
        System.out.println("physicalNumberOfRows is: "+physicalNumberOfRows);

        //columnCount
        int columnCount = ws.getRow(0).getLastCellNum();
        System.out.println("columnCount is: "+columnCount);

        //to retrieve a data
        String row1cell1Data = ws.getRow(1).getCell(1).getStringCellValue();
        System.out.println("row1cell1Data is: "+row1cell1Data);

        String[][] data=new String[rowCount][columnCount];
    
        //To retrieve the entire data
        //1    2
        for(int i=1;i<=rowCount;i++){
        //0   1    2 
        for(int j=0;j<columnCount;j++){
        String allData=ws.getRow(i).getCell(j).getStringCellValue();
        data[i-1][j]=allData;
        
        //String allData=ws.getRow(1).getCell(0).getStringCellValue(); //TestLeaf  data[0][0]
        //String allData=ws.getRow(1).getCell(1).getStringCellValue(); //Vineeth   data[0][1]
        //String allData=ws.getRow(1).getCell(2).getStringCellValue(); /Rajendran  data[0][2]
        
        //String allData=ws.getRow(2).getCell(0).getStringCellValue();  //TCS      data[1][0]
        //String allData=ws.getRow(2).getCell(1).getStringCellValue();  //Bharath  data[1][1]
        ////String allData=ws.getRow(2).getCell(2).getStringCellValue();  //Raj    data[1][2]
        }
    }
    
    return data;
    
    }

}
