Feature: Login function of Leaftaps application

Scenario: Login with valid credentials
Given Launch the Browser 
And Load the url
When Enter the username as Demosalesmanager
And Enter the password as crmsfa
And Click the Login button
Then The user should be loggedin

