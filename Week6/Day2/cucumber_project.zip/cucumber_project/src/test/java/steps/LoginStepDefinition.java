package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition {

   public EdgeDriver driver;

   @Given("Launch the Browser")
    public void launchBrowser(){
    driver=new EdgeDriver();
    }

     @And("Load the url")
    public void loadUrl(){
        driver.get("https://leaftaps.com/opentaps/control/main");
    }

    @When("Enter the username as Demosalesmanager")
    public void enterUsername(){
        driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
    }

    @And("Enter the password as crmsfa")
    public void enterPassword(){
        driver.findElement(By.id("password")).sendKeys("Demosalesmanager");
    }

    @And("Click the Login button")
    public void clickLogin(){
        driver.findElement(By.className("decorativeSubmit")).click();
    }

    @Then("The user should be loggedin")
    public void verifyLogin(){
        System.out.println("Login successful");
    }

}
